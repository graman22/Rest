Execution (either By Junit/or Server based  No change) 


what i did ?
Airport builder

Singleton for service Using Spring Dependency injection based

Service layer for separation of concerns (SOC)

Functionality -> Airport CRUD, Concurrency issues 

Configuration driven way by reading endpoint , file name from application.prpertirs

Exception
To DO RestWeatherCollectorEndpoint ==> updateWeather

Airport & its weather in one common SingletonClass 

DataPointType enum is enforced to give in data side - atleast in java class and Junit tested

created package modified access specifier accordingly

Formating:
I added "myprofile" formatting file under resources folder - The same can be added 
window->preference->java-> code style-> formatter-> import 

after that Ctrl+shift+f in each file (or) "Right click on the project root and select Source -> Format."

